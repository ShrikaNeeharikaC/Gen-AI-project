import os
import json
import numpy as np
import lancedb
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from langchain_google_genai import ChatGoogleGenerativeAI
from langfuse import get_client, Langfuse
from langfuse.langchain import CallbackHandler
from postgres_writer import insert_test_case, get_test_case_json_by_story_id

# Load environment variables and initialize models
load_dotenv()
embedding_model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")

# Configuration
LANCE_DB_PATH = "my_lance_db"
TABLE_NAME    = "user_stories"
TOP_K         = 3

# Initialize Langfuse clients
langfuse         = get_client()
langfuse_handler = CallbackHandler()
lf_prompt        = Langfuse()

# Retrieve registered prompt metadata
prompt_obj = lf_prompt.get_prompt("prompt1", label="production")

# Load prompt template and ground truth
with open("test_case_prompt.txt", "r", encoding="utf-8") as f:
    INSTRUCTIONS = f.read().strip()
with open("ground_truth.txt", "r", encoding="utf-8") as f:
    GROUND_TRUTH = f.read().strip()

# Initialize LLM with Langfuse callbacks
llm = ChatGoogleGenerativeAI(
    model="models/gemini-2.0-flash",
    temperature=0.3,
    google_api_key=os.environ["GOOGLE_API_KEY"],
    callbacks=[langfuse_handler]
)

# Connect to LanceDB for RAG context
db    = lancedb.connect(LANCE_DB_PATH)
table = db.open_table(TABLE_NAME)

# Ensure directory for saving prompts
os.makedirs("sent_prompts", exist_ok=True)

def tfidf_cosine(a: str, b: str) -> float:
    vect  = TfidfVectorizer().fit([a, b])
    tfidf = vect.transform([a, b])
    return float((tfidf * tfidf.T).toarray()[0, 1])

def semantic_similarity(a: str, b: str) -> float:
    emb = embedding_model.encode([a, b])
    return float(np.dot(emb[0], emb[1]) / (np.linalg.norm(emb[0]) * np.linalg.norm(emb[1])))

def flatten_test_cases(tc_json) -> str:
    if isinstance(tc_json, dict) and "test_cases" in tc_json:
        entries = tc_json["test_cases"]
    elif isinstance(tc_json, list):
        entries = tc_json
    else:
        return str(tc_json)
    return "\n".join(
        item.get("description", json.dumps(item)) if isinstance(item, dict) else str(item)
        for item in entries
    )

def generate_test_case_with_prompt(story_id: str, prompt_file: str):
    # Fetch story document
    row = next((r for r in table.search().to_list() if r["storyID"] == story_id), None)
    if not row or not row.get("doc_content_text"):
        print(f"❌ Story '{story_id}' not found or empty")
        return None
    main_text = row["doc_content_text"].strip()

    # RAG context retrieval
    vec  = np.array(row["vector"])
    sims = table.search(vec).distance_type("cosine").limit(TOP_K + 5).to_list()
    contexts, sids = [], []
    for doc in sims:
        sid = doc["storyID"]
        if sid == story_id:
            continue
        tc = get_test_case_json_by_story_id(sid)
        if tc:
            contexts.append(f"--- From {sid} ---\n{json.dumps(tc, indent=2)}")
            sids.append(sid)
        if len(contexts) >= TOP_K:
            break
    context_text = "\n\n".join(contexts) or "[No similar context found]"

    # Assemble full prompt and audit it
    full_prompt = (
        f"{INSTRUCTIONS}\n\n"
        "=======================\n"
        f"📄 STORY ({story_id}):\n{main_text}\n\n"
        "=======================\n"
        f"📚 CONTEXT TEST CASES:\n{context_text}"
    )
    audit_path = os.path.join("sent_prompts", f"{prompt_file.replace('.txt','')}_{story_id}.txt")
    with open(audit_path, "w", encoding="utf-8") as f:
        f.write(full_prompt)

    # LLM generation span tagged as a prompt generation
    with langfuse.start_as_current_span(name="generation") as span:
        # Tag prompt metadata
        span.update_trace(input={
            "story_id": story_id,
            "span_type": "generation",
            "prompt_name": prompt_obj.name,
            "prompt_version": prompt_obj.version,
            "full_prompt": full_prompt
        })

        # Invoke LLM and record output
        raw = llm.invoke(full_prompt).content.strip()
        span.update_trace(output={"raw_output": raw})

        # Clean Markdown fences if present
        if raw.startswith("```"):
            raw = raw[7:]
        if raw.endswith("```"):
            raw = raw.strip("`")

        try:
            testcases = json.loads(raw)
            insert_test_case(story_id, row["storyDescription"], testcases)
            span.score(
                name="test_case_json_valid",
                value=True,
                data_type="BOOLEAN",
                comment="Valid JSON"
            )
        except Exception as e:
            span.score(
                name="test_case_json_valid",
                value=False,
                data_type="BOOLEAN",
                comment=str(e)
            )
            return None

        # Compute similarity metrics
        gt_flat    = GROUND_TRUTH
        out_flat   = flatten_test_cases(testcases)
        tf_score   = tfidf_cosine(gt_flat, out_flat)
        sem_score  = semantic_similarity(gt_flat, out_flat)
        avg_score  = (tf_score + sem_score) / 2

        # Log similarity scores on the same span
        span.score(
            name="tfidf_similarity",
            value=tf_score,
            data_type="NUMERIC",
            comment="TF-IDF similarity"
        )
        span.score(
            name="semantic_similarity",
            value=sem_score,
            data_type="NUMERIC",
            comment="Semantic similarity"
        )
        span.score(
            name="avg_similarity",
            value=avg_score,
            data_type="NUMERIC",
            comment="Average similarity"
        )

        # Return the scores for printing
        return {
            "prompt_file": prompt_file,
            "tfidf_similarity": tf_score,
            "semantic_similarity": sem_score,
            "avg_similarity": avg_score
        }

def run_all_prompts_for_story(story_id: str, prompt_folder: str = "prompts"):
    results = []
    for pf in os.listdir(prompt_folder):
        if not pf.endswith(".txt"):
            continue
        text = open(os.path.join(prompt_folder, pf), encoding="utf-8").read().strip()
        # Ensure prompt is registered in Langfuse
        langfuse.create_prompt(
            name=pf.replace(".txt", ""),
            prompt=text,
            type="text",
            labels=["production"],
            config={"model":"gemini-2.0-flash","stage":"evaluation"}
        )
        print(f"\n▶ Running {pf}")
        res = generate_test_case_with_prompt(story_id, pf)
        if res:
            results.append(res)
            # Print the similarity scores for this prompt
            print(f"Scores for prompt '{pf}':")
            print(f"  TF-IDF similarity:   {res['tfidf_similarity']:.4f}")
            print(f"  Semantic similarity: {res['semantic_similarity']:.4f}")
            print(f"  Average similarity:  {res['avg_similarity']:.4f}")
    langfuse.flush()

if __name__ == "__main__":
    run_all_prompts_for_story("US2")
