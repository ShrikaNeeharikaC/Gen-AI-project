import requests
import json

questions = [
    "Why did my Jenkins deploy fail?",
    "Why did my GitLab CI test fail intermittently?",
    # Add more questions as needed
]

eval_data = []

for q in questions:
    data = {"message": q, "session_id": "eval_session"}
    resp = requests.post("http://127.0.0.1:5004/api/chat", json=data)
    result = resp.json()
    eval_data.append({
        "question": q,
        "contexts": result.get("contexts", []),
        "answer": result.get("response", ""),
        "ground_truth": ""  # Fill this in manually with the ideal answer
    })

with open("rag_eval_data.json", "w") as f:
    json.dump(eval_data, f, indent=2)
