import os
import json
import numpy as np
import lancedb
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from langchain_google_genai import ChatGoogleGenerativeAI
from langfuse import get_client
from langfuse.langchain import CallbackHandler
from postgres_writer import (
    insert_test_case,
    get_test_case_json_by_story_id,
    get_all_generated_story_ids
)

# Load environment variables and embedding model
load_dotenv()
embedding_model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")

# Configuration
LANCE_DB_PATH = "my_lance_db"
TABLE_NAME    = "user_stories"
TOP_K         = 3

# Initialize Langfuse client and callback handler
langfuse         = get_client()
langfuse_handler = CallbackHandler()  # Default handler attaches to spans

# Load the custom prompt text
with open("test_case_prompt.txt", "r", encoding="utf-8") as f:
    INSTRUCTIONS = f.read()

# Initialize the LLM with Langfuse callbacks
llm = ChatGoogleGenerativeAI(
    model="models/gemini-2.0-flash",
    temperature=0.3,
    google_api_key=os.environ["GOOGLE_API_KEY"],
    callbacks=[langfuse_handler]
)

# Connect to LanceDB and open the target table
db    = lancedb.connect(LANCE_DB_PATH)
table = db.open_table(TABLE_NAME)

def generate_test_case_for_story(story_id, table_ref=table, llm_ref=llm):
    """
    Generate and store test cases for a single story,
    with full prompt/output tracing to Langfuse.
    """
    # Fetch the story document
    all_rows = table_ref.search().to_list()
    row      = next((r for r in all_rows if r["storyID"] == story_id), None)
    if not row:
        print(f"❌ Story ID '{story_id}' not found.")
        return  # Missing story handled
    story_description = row["storyDescription"]
    main_text         = row.get("doc_content_text", "").strip()
    if not main_text:
        print(f"❌ Skipping {story_id} — missing content.")
        return  # Skip if no text

    # Build RAG context from similar story embeddings
    vector   = np.array(row["vector"])
    sims     = table_ref.search(vector).distance_type("cosine").limit(TOP_K + 5).to_list()
    context_parts, similar_ids = [], []
    for doc in sims:
        sid = doc["storyID"]
        if sid == story_id:
            continue
        tc = get_test_case_json_by_story_id(sid)
        if tc:
            context_parts.append(f"--- From {sid} ---\n{json.dumps(tc, indent=2)}")
            similar_ids.append(sid)
        if len(context_parts) >= TOP_K:
            break
    context_text = "\n\n".join(context_parts) or "[No similar context found]"

    # Assemble the final prompt string
    full_prompt = (
        f"{INSTRUCTIONS.strip()}\n\n"
        f"=======================\n"
        f"📄 STORY ({story_id}):\n{main_text}\n\n"
        f"=======================\n"
        f"📚 CONTEXT TEST CASES:\n{context_text}"
    )

    # Create a Langfuse span for test-case generation
    with langfuse.start_as_current_span(name="test-case-generation") as span:
        # Record inputs in trace
        span.update_trace(
            input={
                "story_id": story_id,
                "description": story_description,
                "similar_ids": similar_ids,
                "prompt": full_prompt
            },
            user_id="system",
            session_id=f"story-{story_id}"
        )
        # Invoke the LLM (callback handler logs prompt/output)
        response = llm_ref.invoke(full_prompt)
        raw      = response.content.strip()
        span.update_trace(output={"raw_output": raw})

        # Clean markdown fences and parse JSON
        if raw.startswith("```"):
            raw = raw[7:]
        if raw.endswith("```"):
            raw = raw[:-3]
        try:
            testcases = json.loads(raw)
            insert_test_case(
                story_id=story_id,
                story_description=story_description,
                test_case_json=testcases
            )
            span.update_trace(output={"parsed_count": len(testcases)})
            # Score for successful JSON parsing (BOOLEAN)
            span.score(
                name="test_case_json_valid",
                value=True,
                data_type="BOOLEAN",
                comment="Test case JSON parsed successfully"
            )
            print(f"✅ Test cases inserted for {story_id}.")
        except json.JSONDecodeError as err:
            span.update_trace(output={"error": str(err), "sample": raw[:200]})
            # Score for failed JSON parsing (BOOLEAN)
            span.score(
                name="test_case_json_valid",
                value=False,
                data_type="BOOLEAN",
                comment=f"Test case JSON parse error: {err}"
            )
            print(f"❌ JSON parse error for {story_id}: {err}")

def Chat_RAG(user_query, table_ref=table, top_k=TOP_K):
    """
    Perform RAG search over user stories and return test cases.
    """
    with langfuse.start_as_current_span(name="chat-rag-query") as span:
        span.update_trace(input={"query": user_query, "top_k": top_k}, user_id="user")
        vec     = embedding_model.encode(user_query).tolist()
        results = table_ref.search(vec).distance_type("cosine").limit(top_k).to_list()
        if not results:
            span.update_trace(output={"error": "No results"})
            # Add a score indicating no relevant stories found (BOOLEAN)
            span.score(
                name="relevant_story_found",
                value=False,
                data_type="BOOLEAN",
                comment="No relevant stories found"
            )
            return {"error": "No relevant stories"}

        output = []
        for res in results:
            sid = res["storyID"]
            output.append({
                "story_id": sid,
                "score":    res["_distance"],
                "test_case": get_test_case_json_by_story_id(sid) or "[None]"
            })
        span.update_trace(output={"count": len(output)})
        # Add a score for the top similarity (NUMERIC)
        span.score(
            name="top_similarity",
            value=results[0]["_distance"],
            data_type="NUMERIC",
            comment="Cosine distance of top result"
        )
        return output  # Return list of matches

if __name__ == "__main__":
    # Identify unprocessed stories
    processed_ids = set(get_all_generated_story_ids())
    pending       = [r for r in table.search().to_list() if r["storyID"] not in processed_ids]
    print(f"🟡 {len(pending)} stories to process.")

    # Batch span for overall processing
    with langfuse.start_as_current_span(name="batch-test-case-generation") as batch_span:
        batch_span.update_trace(
            input={"total": len(pending), "ids": [r["storyID"] for r in pending]},
            user_id="system",
            session_id="batch-session"
        )
        for row in pending:
            generate_test_case_for_story(row["storyID"])
        batch_span.update_trace(output={"processed": len(pending)})

    # Flush all Langfuse events before exit
    langfuse.flush()
