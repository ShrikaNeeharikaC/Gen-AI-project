import os
import shutil
import json
import lancedb
import fitz
import pyarrow as pa
from docx import Document
from sentence_transformers import SentenceTransformer
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
from langfuse import get_client
from langfuse.langchain import CallbackHandler

# === Initialization ===
load_dotenv()
config = json.load(open("config.json", "r"))
UPLOAD_FOLDER   = config.get("uploaded_docs", "uploaded_docs")
SUCCESS_FOLDER  = "success"
FAILURE_FOLDER  = "failure"
LANCE_DB_PATH   = "my_lance_db"
TABLE_NAME      = "user_stories"

os.makedirs(SUCCESS_FOLDER, exist_ok=True)
os.makedirs(FAILURE_FOLDER, exist_ok=True)

# === Embedding & DB Setup ===
embedding_model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")
db = lancedb.connect(LANCE_DB_PATH)
schema = pa.schema([
    ("vector",          pa.list_(pa.float32(), 768)),
    ("storyID",         pa.string()),
    ("storyDescription",pa.string()),
    ("test_case_content", pa.string()),
    ("filename",        pa.string()),
    ("original_path",   pa.string()),
    ("doc_content_text",pa.string())
])
table = db.create_table(TABLE_NAME, schema=schema, exist_ok=True)
print(f"Table '{TABLE_NAME}' is ready.")

# === LLM & Langfuse Setup ===
llm = ChatGoogleGenerativeAI(
    model="models/gemini-2.0-flash",
    temperature=0.3,
    google_api_key=os.environ["GOOGLE_API_KEY"]
)
langfuse        = get_client()
langfuse_handler= CallbackHandler()

def extract_text(file_path):
    """Extract text from PDF, DOCX, or TXT."""
    try:
        if file_path.endswith(".pdf"):
            with fitz.open(file_path) as doc:
                return "\n".join(page.get_text() for page in doc)
        elif file_path.endswith(".docx"):
            doc = Document(file_path)
            return "\n".join(p.text for p in doc.paragraphs)
        elif file_path.endswith(".txt"):
            return open(file_path, encoding="utf-8").read()
        return None
    except Exception as e:
        print(f"❌ Error reading {file_path}: {e}")
        return None

def summarize_in_chunks(text, chunk_size=4000):
    """
    Split text into chunks and summarize each in one sentence,
    tracing each LLM call as a Langfuse generation span.
    """
    chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]
    summaries = []
    for idx, chunk in enumerate(chunks[:3]):
        prompt = f"Summarize the following document section in 1 sentence:\n\n{chunk}"
        with langfuse.start_as_current_generation(
            name="chunk-summary",
            model="gemini-2.0-flash",
            input={"chunk_index": idx, "prompt": prompt},
            model_parameters={"temperature": 0.3}
        ) as generation:
            try:
                response = llm.invoke(prompt, config={"callbacks":[langfuse_handler]})
                raw_output = response.content.strip()
                generation.update(output={"raw_output": raw_output})
                summaries.append(raw_output)
            except Exception as err:
                generation.update(output={"error": str(err)})
                summaries.append("[Summary failed]")
                print(f"❌ LLM failed on chunk {idx}: {err}")
    return " ".join(summaries)

def story_id_exists(table, story_id):
    """Check if a storyID already exists in LanceDB."""
    try:
        return not table.to_pandas().query("storyID == @story_id").empty
    except Exception:
        return False

# === Main Ingestion Loop ===
with langfuse.start_as_current_span(name="batch-ingestion") as batch_span:
    batch_span.update_trace(input={"upload_folder": UPLOAD_FOLDER}, user_id="system")
    for file in os.listdir(UPLOAD_FOLDER):
        file_path = os.path.join(UPLOAD_FOLDER, file)
        if os.path.isdir(file_path):
            continue

        print(f"📄 Processing {file}...")
        text = extract_text(file_path)
        if not text:
            print(f"❌ Skipping {file} — could not extract text.")
            shutil.move(file_path, os.path.join(FAILURE_FOLDER, file))
            continue

        story_id = os.path.splitext(file)[0]
        if story_id_exists(table, story_id):
            print(f"⚠️ Skipping {file} — storyID '{story_id}' exists.")
            shutil.move(file_path, os.path.join(FAILURE_FOLDER, file))
            continue

        story_description = summarize_in_chunks(text)
        try:
            embedding = embedding_model.encode(text).tolist()
        except Exception as e:
            print(f"❌ Embedding failed for {file}: {e}")
            shutil.move(file_path, os.path.join(FAILURE_FOLDER, file))
            continue

        table.add([{
            "vector": embedding,
            "storyID": story_id,
            "storyDescription": story_description,
            "test_case_content": "",
            "filename": file,
            "original_path": file_path,
            "doc_content_text": text
        }])
        try:
            shutil.move(file_path, os.path.join(SUCCESS_FOLDER, file))
            print(f"✅ Moved {file} to success folder.")
        except Exception as e:
            print(f"❌ Move failed for {file}: {e}")
            shutil.move(file_path, os.path.join(FAILURE_FOLDER, file))

    batch_span.update_trace(output={"status": "completed"})
